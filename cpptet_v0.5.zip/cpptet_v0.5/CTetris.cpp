#include "CTetris.h"

CTetris::CTetris(int dy, int dx)
: Tetris(dy, dx){ }